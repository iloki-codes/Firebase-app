export const options = {
    title: "Select Avatar",
    storageOptions: {
        skipBackup: true,
        path: 'images'
    }
}